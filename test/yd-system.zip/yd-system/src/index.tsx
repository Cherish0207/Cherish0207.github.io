export interface Result {
  title: string;
}

export interface IDdata {
  data: string;
  result: Result;
}