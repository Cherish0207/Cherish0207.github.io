const path = require("path");
const awaitLoader = require("./loader");
const fs = require("fs");
// console.log(fs.readFileSync(path.join(__dirname, "src/index.js")));
const filePath = path.join(__dirname, "src/index.js");
const fileContent = fs.readFileSync(filePath, {
  encoding: "utf-8"
});
// console.log(fileContent);
const res = awaitLoader(fileContent);
console.log(res);
