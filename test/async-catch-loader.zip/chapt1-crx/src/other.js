console.log('other.js')
jquery('body img').css('width', '400px')