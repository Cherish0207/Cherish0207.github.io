async function func() {
  await asyncFunc();
} 
// console.log('index.js')

// import './index.css'
// import './b.less'
// import 'bootstrap/dist/css/bootstrap.css'
// // import $ from 'jquery'
// console.log($)
// console.log(window.$)
// $('body').css('background', '#daa520')
// console.log("PRODUCTION: ", PRODUCTION)
// console.log("DEVELOPMENT: ", DEVELOPMENT)
// console.log("BROWSER_SUPPORTS_HTML5: ", DEVELOPMENT)
// console.log(VERSION)
// setTimeout(() => {
//   console.log('箭头函数打印')
// })

// setTimeout(function () {
//   console.log('普通函数打印')
// })

// class Person {
//   constructor(name) {
//     this.name = name
//   }
// }
// let p = new Person('crx')
// console.log(p)

// class Dog {
//   name = '大黄'
//   static color = 'red'
// }
// let d = new Dog()
// console.dir(d)
// console.dir(Dog)

// function* fn() {
//   yield 1;
//   yield 2;
//   return 3;
// }
// let newFn = fn();
// console.log(newFn.next());
// console.log(newFn.next());
// console.log(newFn.next());
// console.log(newFn.next());
// console.log(newFn.next());

// let str = "abc";
// console.log(str.includes("a"));
