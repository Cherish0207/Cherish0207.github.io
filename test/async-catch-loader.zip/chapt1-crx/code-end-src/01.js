//day.1 代码残局 
/**
 * 要求：
 * 1.完善memoize函数并考虑可扩展性
 * 2.执行结果要求console.log("memoize")只执行一次
 */
const memoize = fn => {
  // 1. 笨方法1 -- crx
  /* let count = 1;
  let res;
  return () => {
    if(count > 0) {
      res = fn()
      count--
    }
    return res
  } */
  // 2. 笨方法2 -- crx
  /* let res;
  return () => {
    if(!fn.flag) {
      res = fn()
      fn.flag = true
    }
    return res
  } */
  // 3. 答案
  const cache = new Map();
  const cached = function(val) {
    return cache.has(val)
      ? cache.get(val)
      : cache.set(val, fn.call(this, val)) && cache.get(val);
  };
  cached.cache = cache;
  return cached;
};
function yideng(){
	if(self.self == self){
		console.log("memoize")
		return "京程一灯";
	}
}
const result = memoize(yideng);
console.log(result());
console.log(result());
console.log(result());