const yideng = () => {
  console.log(arguments);
  arguments.forEach(function(element) {
    element
  }, this);
  return (...args) => {

  };
};
const minMax = yideng(Math.min, Math.max);
minMax(1, 2, 3, 4, 5);
