const path = require("path");
const htmlWebpackPlugin = require("html-webpack-plugin");
const webpack = require("webpack");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

module.exports = {
  // // 打包的入口文件
  // entry: ["@babel/polyfill", "./src/index.js"],
  entry: {
    index: "./src/index.js",
    other: "./src/other.js"
  },
  // // 打包的输出
  output: {
    path: path.resolve("./dist"),
    filename: "[name].js"
  },
  devtool: "cheap-module-eval-source-map",
  // // 环境
  mode: "development",
  // watch: true
  devServer: {
    open: true
  },
  plugins: [
    new htmlWebpackPlugin({
      filename: "index.html",
      template: "./index.html",
      chunks: ["index", "other"]
    }),
    new htmlWebpackPlugin({
      filename: "other.html",
      template: "./other.html",
      chunks: ["other"]
    }),
    new CleanWebpackPlugin(),
    new CopyWebpackPlugin([
      {
        from: path.join(__dirname, "assets"),
        to: "assets"
      }
    ]),
    new webpack.BannerPlugin({
      banner:
        "hash:[hash], chunkhash:[chunkhash], name:[name], filebase:[filebase], query:[query], file:[file]"
      // raw: true, // 如果值为 true，将直出，不会被作为注释
      // entryOnly: boolean, // 如果值为 true，将只在入口 chunks 文件中添加
      // test: string | RegExp | Array,
      // include: string | RegExp | Array,
      // exclude: string | RegExp | Array,
    }),
    new webpack.DefinePlugin({
      PRODUCTION: JSON.stringify(true),
      DEVELOPMENT: JSON.stringify("true"),
      VERSION: JSON.stringify("5fa3b9"),
      BROWSER_SUPPORTS_HTML5: true,
      TWO: "1+1",
      "typeof window": JSON.stringify("object")
    }),
    new webpack.ProvidePlugin({
      $: "jquery",
      jquery: "jquery"
    })
  ],
  module: {
    rules: [
      // {
      //   test: require.resolve('jquery'),
      //   use: {
      //     loader: 'expose-loader',
      //     options: '$'
      //   }
      // },
      // 配置用来解析.css文件的loader(style-loader和css-loader)
      {
        // 用正则匹配当前访问的文件的后缀名是  .css
        test: /\.css$/,
        use: ["style-loader", "css-loader"]
      },
      {
        test: /\.less$/,
        use: ["style-loader", "css-loader", "less-loader"]
      },
      {
        test: /\.s(a|c)ss$/,
        use: ["style-loader", "css-loader", "sass-loader"]
      },
      // {
      //   test: /\.(jpg|bmp|woff|woff2|ttf|eot|svg|png|gif|jpeg)$/,
      //   use: 'file-loader'
      // },
      {
        test: /\.(jpg|bmp|woff|woff2|ttf|eot|svg|png|gif|jpeg)$/,
        use: [
          {
            loader: "url-loader",
            options: {
              limit: 5 * 1024,
              outputPath: "images",
              name: "[name]-[hash:4].[ext]"
            }
          }
        ]
      },
      {
        test: /\.js$/,
        use: {
          loader: "babel-loader"
        },
        exclude: /node_modules/
      }
    ]
  }
};
