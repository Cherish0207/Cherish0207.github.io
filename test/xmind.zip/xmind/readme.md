[Vue Function-based API RFC](https://zhuanlan.zhihu.com/p/68477600)

[前端工程化（5）：你所需要的npm知识储备都在这了](https://juejin.im/post/5d08d3d3f265da1b7e103a4d)

[uni-app路由的封装](https://juejin.im/post/5d0314a5f265da1ba77ca05b?utm_source=wechat)

[uni-app缓存器的封装](https://juejin.im/post/5d08a5c2f265da1bb003c0f8)