phoenix: 
- css分离, css主题颜色 

事件的stopPropagation -- click.stop阻止单击事件继续传播 passive
完善js事件的xmind 和 vue.xmind的事件修饰符

- 完成整理promise，symbol的使用
- 公司项目优化实践，
- bfc，透明，
- node和express 
- created 和 activated 中 重复操作的函数 可以借用单例模式  
- event passive

es6：
- Iterator 和 for...of 循环
- Generator 函数的语法
- 数组的扩展
- Class 的基本语法
- Generator 函数的异步应用
- Set 和 Map 数据结构
- Module 的语法
- Module 的加载实现
- Promise 对象
- let 和 const 命令
- Class 的继承

- async 函数
- 函数的扩展
- 对象的扩展，对象的新增方法
- Symbol
- Proxy
- Reflect
- 变量的解构赋值
- 字符串的扩展，字符串的新增方法，正则的扩展，数值的扩展

points:
1. let const var的区别;Require和import的区别
2. es6中数组的方法，排序的简单实现
3. extends原理继承方式
4. promise出现之前怎么实现异步--回调，

node，express:
- Web Worker 
- Node 的 REPL 环境    

css：
1. 水平垂直居中
2. 哪些属性会触发bfc
3. opacity background 区别

js：
- Js有哪些类型检测的方法，
- 闭包，词法作用域
- eventloop，
- 原型链继承方式  
- 抖动机制

http协议： 
- http和https http1和http2区别

vue：
-  v_show 和 v-if (v-show 不可以用在template标签上)
-  v-for的key   
-  实现自定义指令 
-  vue.use的作用是什么

-  vuex中的mution和actrion的区别  
-  vue-router 钩子 

-  双向绑定原理
